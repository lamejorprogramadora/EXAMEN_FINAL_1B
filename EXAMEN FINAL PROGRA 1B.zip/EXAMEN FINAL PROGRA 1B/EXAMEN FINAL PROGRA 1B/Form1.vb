﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim total1 As Double
        Dim total2 As Double
        Dim total3 As Double
        Dim total4 As Double
        Dim total5 As Double
        Dim subtotal As Double
        Dim TOTAL As Double
        Dim IVA As Double
        Dim Vuelto As Double

        If (ComboBox1.Text = "TECLADO CON CABLE USB") Then
            TextBox10.Text = "100"
        End If
        If (ComboBox1.Text = "MEMORIA USB 16 GB") Then
            TextBox10.Text = "80"
        End If
        If (ComboBox1.Text = "MOUSE INALAMBRICO") Then
            TextBox10.Text = "120"
        End If

        If (ComboBox1.Text = "COMPUTADORA DELL") Then
            TextBox10.Text = "4000"
        End If
        If (ComboBox1.Text = "AIRE COMPRIMIDO") Then
            TextBox10.Text = "70"
        End If

        If (ComboBox2.Text = "TECLADO CON CABLE USB") Then
            TextBox11.Text = "100"
        End If
        If (ComboBox2.Text = "MEMORIA USB 16 GB") Then
            TextBox11.Text = "80"
        End If
        If (ComboBox2.Text = "MOUSE INALAMBRICO") Then
            TextBox11.Text = "120"
        End If
        If (ComboBox2.Text = "COMPUTADORA DELL") Then
            TextBox11.Text = "4000"
        End If
        If (ComboBox2.Text = "AIRE COMPRIMIDO") Then
            TextBox11.Text = "70"
        End If

        If (ComboBox3.Text = "TECLADO CON CABLE USB") Then
            TextBox13.Text = "100"
        End If
        If (ComboBox3.Text = "MEMORIA USB 16 GB") Then
            TextBox13.Text = "80"
        End If
        If (ComboBox3.Text = "MOUSE INALAMBRICO") Then
            TextBox13.Text = "120"
        End If
        If (ComboBox3.Text = "COMPUTADORA DELL") Then
            TextBox13.Text = "4000"
        End If
        If (ComboBox3.Text = "AIRE COMPRIMIDO") Then
            TextBox13.Text = "70"
        End If

        If (ComboBox4.Text = "TECLADO CON CABLE USB") Then
            TextBox15.Text = "100"
        End If
        If (ComboBox4.Text = "MEMORIA USB 16 GB") Then
            TextBox15.Text = "80"
        End If
        If (ComboBox4.Text = "MOUSE INALAMBRICO") Then
            TextBox15.Text = "120"
        End If
        If (ComboBox4.Text = "COMPUTADORA DELL") Then
            TextBox15.Text = "4000"
        End If
        If (ComboBox4.Text = "AIRE COMPRIMIDO") Then
            TextBox15.Text = "70"
        End If

        If (ComboBox5.Text = "TECLADO CON CABLE USB") Then
            TextBox17.Text = "100"
        End If
        If (ComboBox5.Text = "MEMORIA USB 16 GB") Then
            TextBox17.Text = "80"
        End If
        If (ComboBox5.Text = "MOUSE INALAMBRICO") Then
            TextBox17.Text = "120"
        End If
        If (ComboBox5.Text = "COMPUTADORA DELL") Then
            TextBox17.Text = "4000"
        End If
        If (ComboBox5.Text = "AIRE COMPRIMIDO") Then
            TextBox17.Text = "70"
        End If
        total1 = Convert.ToDouble(TextBox9.Text) * Convert.ToDouble(TextBox10.Text)
        total2 = Convert.ToDouble(TextBox12.Text) * Convert.ToDouble(TextBox11.Text)
        total3 = Convert.ToDouble(TextBox14.Text) * Convert.ToDouble(TextBox13.Text)
        total4 = Convert.ToDouble(TextBox16.Text) * Convert.ToDouble(TextBox15.Text)
        total5 = Convert.ToDouble(TextBox18.Text) * Convert.ToDouble(TextBox17.Text)
        subtotal = total1 + total2 + total3 + total4 + total5
        IVA = subtotal * 0.12
        TOTAL = subtotal + IVA
        Vuelto = Convert.ToDouble(TextBox3.Text) - TOTAL
        TextBox1.Text = subtotal
        TextBox2.Text = TOTAL
        TextBox8.Text = Vuelto


    End Sub

    Private Sub TextBox10_TextChanged(sender As Object, e As EventArgs) Handles TextBox10.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        TextBox9.Text = ""
        TextBox10.Text = ""
        TextBox11.Text = ""
        TextBox12.Text = ""
        TextBox13.Text = ""
        TextBox14.Text = ""
        TextBox15.Text = ""
        TextBox16.Text = ""
        TextBox17.Text = ""
        TextBox18.Text = ""
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
        ComboBox4.Text = ""
        ComboBox5.Text = ""
    End Sub

    Private Sub TextBox17_TextChanged(sender As Object, e As EventArgs) Handles TextBox17.TextChanged

    End Sub

    Private Sub TextBox18_TextChanged(sender As Object, e As EventArgs) Handles TextBox18.TextChanged

    End Sub

    Private Sub ComboBox5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox5.SelectedIndexChanged

    End Sub

    Private Sub TextBox15_TextChanged(sender As Object, e As EventArgs) Handles TextBox15.TextChanged

    End Sub

    Private Sub TextBox16_TextChanged(sender As Object, e As EventArgs) Handles TextBox16.TextChanged

    End Sub

    Private Sub ComboBox4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox4.SelectedIndexChanged

    End Sub

    Private Sub TextBox13_TextChanged(sender As Object, e As EventArgs) Handles TextBox13.TextChanged

    End Sub

    Private Sub TextBox14_TextChanged(sender As Object, e As EventArgs) Handles TextBox14.TextChanged

    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox3.SelectedIndexChanged

    End Sub

    Private Sub TextBox11_TextChanged(sender As Object, e As EventArgs) Handles TextBox11.TextChanged

    End Sub

    Private Sub TextBox12_TextChanged(sender As Object, e As EventArgs) Handles TextBox12.TextChanged

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub

    Private Sub TextBox9_TextChanged(sender As Object, e As EventArgs) Handles TextBox9.TextChanged

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs) Handles TextBox8.TextChanged

    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click

    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
